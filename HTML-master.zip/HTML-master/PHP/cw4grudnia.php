<form action"" method="POST">
    Podaj a: <input type=text name"a"/><br/>
    Podaj b: <input type=text name"b"/><br/>
    <input type=submit value="Wyślij"/>
    
<?php
@$a=$_POST['a'];
@$b=$_POST['b'];
$suma=$a+$b;
?>

