-- MySQL dump 10.16  Distrib 10.1.40-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: baz2910
-- ------------------------------------------------------
-- Server version	10.1.40-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `samochody`
--

DROP TABLE IF EXISTS `samochody`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `samochody` (
  `id_S` int(11) NOT NULL AUTO_INCREMENT,
  `marka` varchar(30) DEFAULT NULL,
  `model` varchar(30) DEFAULT NULL,
  `rok_pr` int(11) DEFAULT NULL,
  `kolor` varchar(30) DEFAULT NULL,
  `cena` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_S`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin2;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `samochody`
--

LOCK TABLES `samochody` WRITE;
/*!40000 ALTER TABLE `samochody` DISABLE KEYS */;
INSERT INTO `samochody` VALUES (1,'Toyota','Yaris',1999,'Srebrny',2500),(2,'Toyota','Hilux',2011,'Ciemnozielony',64900),(3,'Toyota','Corolla',2019,'Czerwony',94900),(4,'Toyota','Prius',2006,'Srebrny',17200),(5,'Dodge','Charger',2014,'Srebrno-Czarny',73900),(6,'Dodge','RAM',2017,'Czarny',99000),(7,'Dodge','Nitro',2008,'Czarny',35000),(8,'Dodge','Charger',1973,'Srebrny',43000),(9,'Bentley','Continental GT',2004,'Czerwony',115000),(10,'Bentley','Arnage',2004,'Granatowy',237000),(11,'Bentley','Bentayga',2018,'Czarny',950000),(12,'Bentley','Mulsanne',2018,'Srebrny',1559000),(13,'Chevrolet','Camaro',1979,'Czarny',43000),(14,'Chevrolet','Camaro',2017,'Żółty',150000),(15,'Chevrolet','Cruze',2012,'Żółty',20600),(16,'Chevrolet','Corvette',2008,'Niebieski',121770),(17,'Ford','F150',2019,'Czarny',564570),(18,'Ford','Mustang',2016,'Czarny',385000),(19,'Ford','Ranger',2019,'Niebieski',248189),(20,'Ford','C-MAX',2008,'Zielony',14900),(21,'Bentley','Eight',1991,'Czarny',39900),(22,'Toyota','Supra',2008,'Czerwony',550000),(23,'Toyota','Supra',1993,'Czerwony',399000);
/*!40000 ALTER TABLE `samochody` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-29 15:27:30
