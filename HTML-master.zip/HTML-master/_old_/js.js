console.log("Hello - plik zewnętrzny");

let imie = "Damian";
let wiek = 17;
let zawod = ["Uczeń", "Programista"];
let czy_lubi_informatyke = true;
console.log("Imie = ", imie,
			"wiek = ", wiek,
			"zawod = ", zawod
			"czy_lubi_informatyke", czy_lubi_informatyke);
imie = "Janek";
wiek = "20";
zawod = "Uczen";

console.log("Imie = ", imie,
			"wiek = ", wiek,
			"zawod = ", zawod
			"czy_lubi_informatyke", czy_lubi_informatyke);
// deklaracja obiektu
let butelka = {
		objetosc : 1.25,
		zawartosc : ["woda","E250","konserwanty"],
		wymiary : [100,200]
		napijsie : function() {
				console.log("PIJE!");
		}
};
/**
	wyświetlanie informacji o obiekcie
**/

console.log(butelka);
console.log(butelka.objetosc);
butelka.napijsie();

butelka.objetosc=2;
console.log(butelka)

//okno informacyjne
window.alert("Hello Word!");

//okno decyzyjne
let odpowiedz = window.confirm("Czy jesteś teraz na lekcji?");
console.log(odpowiedz);

//okno tekstowe
imie = window.prompt("Wprowadz swoje imie");
colsole.log(imie);

/** I
Zadanie:
	Przygotuj obiekt klient z polamni:
		-imie
		-nazwisko
		-wiek
		-zgoda_marketingowa
	Uzupełnij zmienne przy użyciu window.prompt, window.confirm oraz 
	uzupełnione wartości wyświetl przy użyciu window.alert oraz console.log
**/
 